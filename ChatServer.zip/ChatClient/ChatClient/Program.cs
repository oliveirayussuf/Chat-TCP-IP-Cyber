﻿using System;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace ChatClient
{
    class Client
    {
        private static NetworkStream stream;
        private static int cipherType;
        private static string username;

        static void Main(string[] args)
        {
            Console.Write("Digite seu nome: ");
            username = Console.ReadLine();

            Console.WriteLine("Escolha a cifra:");
            Console.WriteLine("1 - César");
            Console.WriteLine("2 - Atbash");
            Console.WriteLine("3 - ROT13");
            Console.WriteLine("4 - Vigenère");
            cipherType = int.Parse(Console.ReadLine());

            TcpClient client = new TcpClient("127.0.0.1", 5000);
            stream = client.GetStream();

            Thread receiveThread = new Thread(ReceiveMessages);
            receiveThread.Start();

            while (true)
            {
                string message = Console.ReadLine();
                string encryptedMessage = Encrypt(message, cipherType);
                string packet = $"{cipherType}|{username}|{encryptedMessage}";

                byte[] buffer = Encoding.UTF8.GetBytes(packet);
                stream.Write(buffer, 0, buffer.Length);
            }
        }

        private static void ReceiveMessages()
        {
            byte[] buffer = new byte[1024];
            int byteCount;

            while ((byteCount = stream.Read(buffer, 0, buffer.Length)) != 0)
            {
                string packet = Encoding.UTF8.GetString(buffer, 0, byteCount);
                string[] parts = packet.Split('|');
                if (parts.Length < 3) continue;

                int type = int.Parse(parts[0]);
                string sender = parts[1];
                string cipherText = parts[2];

                string decrypted = Decrypt(cipherText, type);
                Console.WriteLine($"[{sender}] {decrypted}");
            }
        }

        // -------- Criptografia --------
        private static string Encrypt(string text, int type)
        {
            return type switch
            {
                1 => CaesarEncrypt(text, 3),
                2 => AtbashEncrypt(text),
                3 => ROT13(text),
                4 => VigenereEncrypt(text, "KEY"),
                _ => text
            };
        }

        private static string Decrypt(string cipherText, int type)
        {
            return type switch
            {
                1 => CaesarDecrypt(cipherText, 3),
                2 => AtbashDecrypt(cipherText),
                3 => ROT13(cipherText),
                4 => VigenereDecrypt(cipherText, "KEY"),
                _ => cipherText
            };
        }

        private static string CaesarEncrypt(string text, int shift)
        {
            StringBuilder result = new StringBuilder();
            foreach (char c in text)
            {
                if (char.IsLetter(c))
                {
                    char d = char.IsUpper(c) ? 'A' : 'a';
                    result.Append((char)((((c - d + shift) % 26) + d)));
                }
                else result.Append(c);
            }
            return result.ToString();
        }

        private static string CaesarDecrypt(string text, int shift)
        {
            return CaesarEncrypt(text, 26 - shift);
        }

        private static string AtbashEncrypt(string text)
        {
            StringBuilder result = new StringBuilder();
            foreach (char c in text)
            {
                if (char.IsLetter(c))
                {
                    char baseChar = char.IsUpper(c) ? 'A' : 'a';
                    result.Append((char)(baseChar + (25 - (c - baseChar))));
                }
                else result.Append(c);
            }
            return result.ToString();
        }

        private static string AtbashDecrypt(string text) => AtbashEncrypt(text);

        private static string ROT13(string text)
        {
            StringBuilder result = new StringBuilder();
            foreach (char c in text)
            {
                if (char.IsLetter(c))
                {
                    char d = char.IsUpper(c) ? 'A' : 'a';
                    result.Append((char)((((c - d + 13) % 26) + d)));
                }
                else result.Append(c);
            }
            return result.ToString();
        }

        private static string VigenereEncrypt(string text, string key)
        {
            StringBuilder result = new StringBuilder();
            int keyIndex = 0;
            foreach (char c in text)
            {
                if (char.IsLetter(c))
                {
                    char d = char.IsUpper(c) ? 'A' : 'a';
                    int k = char.ToUpper(key[keyIndex % key.Length]) - 'A';
                    result.Append((char)((((c - d + k) % 26) + d)));
                    keyIndex++;
                }
                else result.Append(c);
            }
            return result.ToString();
        }

        private static string VigenereDecrypt(string text, string key)
        {
            StringBuilder result = new StringBuilder();
            int keyIndex = 0;
            foreach (char c in text)
            {
                if (char.IsLetter(c))
                {
                    char d = char.IsUpper(c) ? 'A' : 'a';
                    int k = char.ToUpper(key[keyIndex % key.Length]) - 'A';
                    result.Append((char)((((c - d - k + 26) % 26) + d)));
                    keyIndex++;
                }
                else result.Append(c);
            }
            return result.ToString();
        }
    }
}

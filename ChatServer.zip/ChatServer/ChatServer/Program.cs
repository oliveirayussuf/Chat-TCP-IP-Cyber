﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace ChatServer
{
    class Server
    {
        private TcpListener listener;
        private List<TcpClient> clients = new List<TcpClient>();

        public Server(string ip, int port)
        {
            listener = new TcpListener(IPAddress.Parse(ip), port);
            listener.Start();
            Console.WriteLine($"Servidor iniciado em {ip}:{port}");
            ListenForClients();
        }

        private void ListenForClients()
        {
            while (true)
            {
                TcpClient client = listener.AcceptTcpClient();
                clients.Add(client);
                Console.WriteLine("Novo cliente conectado.");
                var clientThread = new System.Threading.Thread(HandleClient);
                clientThread.Start(client);
            }
        }

        private void HandleClient(object obj)
        {
            TcpClient client = (TcpClient)obj;
            NetworkStream stream = client.GetStream();
            byte[] buffer = new byte[1024];
            int byteCount;

            try
            {
                while ((byteCount = stream.Read(buffer, 0, buffer.Length)) != 0)
                {
                    string packet = Encoding.UTF8.GetString(buffer, 0, byteCount);
                    string[] parts = packet.Split('|');
                    if (parts.Length < 3) continue;

                    int type = int.Parse(parts[0]);
                    string sender = parts[1];
                    string cipherText = parts[2];

                    // 🔓 decifra apenas para log
                    string decrypted = Decrypt(cipherText, type);
                    Console.WriteLine($"[{sender}] disse: {decrypted}");

                    // repassa a mensagem original (com nome e criptografia)
                    BroadcastMessage(packet, client);
                }
            }
            finally
            {
                clients.Remove(client);
                client.Close();
            }
        }

        private void BroadcastMessage(string message, TcpClient excludeClient)
        {
            byte[] buffer = Encoding.UTF8.GetBytes(message);

            foreach (var client in clients)
            {
                if (client == excludeClient) continue;
                NetworkStream stream = client.GetStream();
                stream.Write(buffer, 0, buffer.Length);
            }
        }

        // -------- Decriptação --------
        private string Decrypt(string cipherText, int type)
        {
            return type switch
            {
                1 => CaesarDecrypt(cipherText, 3),
                2 => AtbashDecrypt(cipherText),
                3 => ROT13(cipherText),
                4 => VigenereDecrypt(cipherText, "KEY"),
                _ => cipherText
            };
        }

        private string CaesarDecrypt(string text, int shift)
        {
            StringBuilder result = new StringBuilder();
            foreach (char c in text)
            {
                if (char.IsLetter(c))
                {
                    char d = char.IsUpper(c) ? 'A' : 'a';
                    result.Append((char)((((c - d - shift + 26) % 26) + d)));
                }
                else result.Append(c);
            }
            return result.ToString();
        }

        private string AtbashDecrypt(string text) => AtbashEncrypt(text);

        private string AtbashEncrypt(string text)
        {
            StringBuilder result = new StringBuilder();
            foreach (char c in text)
            {
                if (char.IsLetter(c))
                {
                    char baseChar = char.IsUpper(c) ? 'A' : 'a';
                    result.Append((char)(baseChar + (25 - (c - baseChar))));
                }
                else result.Append(c);
            }
            return result.ToString();
        }

        private string ROT13(string text)
        {
            StringBuilder result = new StringBuilder();
            foreach (char c in text)
            {
                if (char.IsLetter(c))
                {
                    char d = char.IsUpper(c) ? 'A' : 'a';
                    result.Append((char)((((c - d + 13) % 26) + d)));
                }
                else result.Append(c);
            }
            return result.ToString();
        }

        private string VigenereDecrypt(string text, string key)
        {
            StringBuilder result = new StringBuilder();
            int keyIndex = 0;
            foreach (char c in text)
            {
                if (char.IsLetter(c))
                {
                    char d = char.IsUpper(c) ? 'A' : 'a';
                    int k = char.ToUpper(key[keyIndex % key.Length]) - 'A';
                    result.Append((char)((((c - d - k + 26) % 26) + d)));
                    keyIndex++;
                }
                else result.Append(c);
            }
            return result.ToString();
        }

        static void Main(string[] args)
        {
            new Server("127.0.0.1", 5000);
        }
    }
}

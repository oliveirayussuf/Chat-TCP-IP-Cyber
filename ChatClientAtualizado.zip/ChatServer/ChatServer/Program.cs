﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

internal class Server
{
    private static List<TcpClient> clients = new List<TcpClient>();
    private static TcpListener server;

    private static void Main(string[] args)
    {
        int port = 12345;
        server = new TcpListener(IPAddress.Any, port);
        server.Start();
        Console.WriteLine("Servidor iniciado...");

        while (true)
        {
            TcpClient client = server.AcceptTcpClient();
            clients.Add(client);
            Console.WriteLine("Novo cliente conectado");

            Thread clientThread = new Thread(HandleClient);
            clientThread.Start(client);
        }
    }

    private static void HandleClient(object obj)
    {
        TcpClient client = (TcpClient)obj;
        NetworkStream stream = client.GetStream();
        byte[] buffer = new byte[1024];
        int byteCount;

        try
        {
            while ((byteCount = stream.Read(buffer, 0, buffer.Length)) != 0)
            {
                string encryptedMessage = Encoding.UTF8.GetString(buffer, 0, byteCount);

                // Loga a mensagem criptografada
                Console.WriteLine("Mensagem criptografada recebida: " + encryptedMessage);

                // Envia para os demais clients
                BroadcastMessage(encryptedMessage, client);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine("Erro ao lidar com cliente: " + ex.Message);
        }
        finally
        {
            clients.Remove(client);
            client.Close();
            Console.WriteLine("Cliente desconectado");
        }
    }

    private static void BroadcastMessage(string encryptedMessage, TcpClient excludeClient)
    {
        byte[] buffer = Encoding.UTF8.GetBytes(encryptedMessage);

        foreach (TcpClient client in clients)
        {
            if (client != excludeClient)
            {
                try
                {
                    NetworkStream stream = client.GetStream();
                    stream.Write(buffer, 0, buffer.Length);
                }
                catch
                {
                    // Se ocorrer erro, apenas ignora e continua
                }
            }
        }
    }
}

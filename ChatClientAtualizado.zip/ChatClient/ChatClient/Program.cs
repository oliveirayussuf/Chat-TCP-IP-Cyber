﻿using System;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;

internal class Client
{
    private static TcpClient client;
    private static NetworkStream stream;
    private static int cifraType;

    private static string alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private static string keySubstitution = "QWERTYUIOPASDFGHJKLZXCVBNM";

    private static void Main(string[] args)
    {
        Console.OutputEncoding = Encoding.UTF8;

        string serverIp = "192.168.0.110"; // Altere conforme necessário
        int port = 12345;

        client = new TcpClient();
        client.Connect(serverIp, port);

        Console.WriteLine("Conectado ao servidor.");

        Console.WriteLine("Escolha a cifra:");
        Console.WriteLine("1 -> Cifra de César");
        Console.WriteLine("2 -> Substituição Monoalfabética");
        Console.WriteLine("3 -> Cifra de Playfair");
        Console.WriteLine("4 -> Cifra de Vigenère");

        while (!int.TryParse(Console.ReadLine(), out cifraType) || cifraType < 1 || cifraType > 4)
        {
            Console.WriteLine("Opção inválida. Tente novamente.");
        }

        Console.Write("Digite o nome do cliente: ");
        string clientName = Console.ReadLine();

        stream = client.GetStream();

        Thread receiveThread = new Thread(ReceiveMessages);
        receiveThread.Start();

        while (true)
        {
            string message = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(message)) continue;

            string fullMessage = $"{clientName}: {message}";
            string encrypted = Encrypt(fullMessage, cifraType);
            string packet = $"{cifraType}|{encrypted}";

            byte[] buffer = Encoding.UTF8.GetBytes(packet);
            stream.Write(buffer, 0, buffer.Length);
        }
    }

    private static void ReceiveMessages()
    {
        byte[] buffer = new byte[1024];
        int byteCount;

        while ((byteCount = stream.Read(buffer, 0, buffer.Length)) != 0)
        {
            string packet = Encoding.UTF8.GetString(buffer, 0, byteCount);
            string[] parts = packet.Split('|');

            if (parts.Length >= 2)
            {
                int type = int.Parse(parts[0]);
                string cipherText = parts[1];
                string decrypted = Decrypt(cipherText, type);
                Console.WriteLine(decrypted);
            }
        }
    }

    private static string Encrypt(string text, int type)
    {
        return type switch
        {
            1 => CaesarEncrypt(text, 3),
            2 => SubstitutionEncrypt(text),
            3 => PlayfairEncrypt(text, "KEYWORD"),
            4 => VigenereEncrypt(text, "SECRET"),
            _ => text
        };
    }

    private static string Decrypt(string text, int type)
    {
        return type switch
        {
            1 => CaesarDecrypt(text, 3),
            2 => SubstitutionDecrypt(text),
            3 => PlayfairDecrypt(text, "KEYWORD"),
            4 => VigenereDecrypt(text, "SECRET"),
            _ => text
        };
    }

    // ===== Cifra de César =====
    private static string CaesarEncrypt(string input, int shift)
    {
        StringBuilder result = new StringBuilder();
        foreach (char c in input)
        {
            if (char.IsLetter(c))
            {
                char d = char.IsUpper(c) ? 'A' : 'a';
                result.Append((char)(((c - d + shift) % 26) + d));
            }
            else
            {
                result.Append(c);
            }
        }
        return result.ToString();
    }

    private static string CaesarDecrypt(string input, int shift)
    {
        return CaesarEncrypt(input, 26 - shift);
    }

    // ===== Substituição Monoalfabética =====
    private static string SubstitutionEncrypt(string input)
    {
        StringBuilder result = new StringBuilder();
        foreach (char c in input)
        {
            if (char.IsLetter(c))
            {
                char upper = char.ToUpper(c);
                int index = alphabet.IndexOf(upper);
                if (index >= 0)
                {
                    char subst = keySubstitution[index];
                    result.Append(char.IsUpper(c) ? subst : char.ToLower(subst));
                }
            }
            else
            {
                result.Append(c);
            }
        }
        return result.ToString();
    }

    private static string SubstitutionDecrypt(string input)
    {
        StringBuilder result = new StringBuilder();
        foreach (char c in input)
        {
            if (char.IsLetter(c))
            {
                char upper = char.ToUpper(c);
                int index = keySubstitution.IndexOf(upper);
                if (index >= 0)
                {
                    char original = alphabet[index];
                    result.Append(char.IsUpper(c) ? original : char.ToLower(original));
                }
            }
            else
            {
                result.Append(c);
            }
        }
        return result.ToString();
    }

    // ===== Cifra de Playfair =====
    private static char[,] GeneratePlayfairMatrix(string key)
    {
        key = new string(key.ToUpper().Where(char.IsLetter).ToArray()).Replace("J", "I");
        string combined = key + alphabet;
        string matrixKey = new string(combined
            .Where(c => c != 'J')
            .Distinct()
            .ToArray());

        char[,] matrix = new char[5, 5];
        for (int i = 0; i < 25; i++)
        {
            matrix[i / 5, i % 5] = matrixKey[i];
        }
        return matrix;
    }

    private static string PlayfairEncrypt(string text, string key)
    {
        char[,] matrix = GeneratePlayfairMatrix(key);
        text = new string(text.ToUpper().Where(char.IsLetter).ToArray()).Replace("J", "I");

        StringBuilder prepared = new StringBuilder();
        for (int i = 0; i < text.Length; i += 2)
        {
            char a = text[i];
            char b = (i + 1 < text.Length) ? text[i + 1] : 'X';

            if (a == b)
            {
                b = 'X';
                i--;
            }

            prepared.Append(a);
            prepared.Append(b);
        }

        StringBuilder result = new StringBuilder();
        for (int i = 0; i < prepared.Length; i += 2)
        {
            GetPosition(matrix, prepared[i], out int r1, out int c1);
            GetPosition(matrix, prepared[i + 1], out int r2, out int c2);

            if (r1 == r2)
            {
                result.Append(matrix[r1, (c1 + 1) % 5]);
                result.Append(matrix[r2, (c2 + 1) % 5]);
            }
            else if (c1 == c2)
            {
                result.Append(matrix[(r1 + 1) % 5, c1]);
                result.Append(matrix[(r2 + 1) % 5, c2]);
            }
            else
            {
                result.Append(matrix[r1, c2]);
                result.Append(matrix[r2, c1]);
            }
        }
        return result.ToString();
    }

    private static string PlayfairDecrypt(string text, string key)
    {
        char[,] matrix = GeneratePlayfairMatrix(key);
        text = new string(text.ToUpper().Where(char.IsLetter).ToArray());

        StringBuilder result = new StringBuilder();
        for (int i = 0; i < text.Length; i += 2)
        {
            GetPosition(matrix, text[i], out int r1, out int c1);
            GetPosition(matrix, text[i + 1], out int r2, out int c2);

            if (r1 == r2)
            {
                result.Append(matrix[r1, (c1 + 4) % 5]);
                result.Append(matrix[r2, (c2 + 4) % 5]);
            }
            else if (c1 == c2)
            {
                result.Append(matrix[(r1 + 4) % 5, c1]);
                result.Append(matrix[(r2 + 4) % 5, c2]);
            }
            else
            {
                result.Append(matrix[r1, c2]);
                result.Append(matrix[r2, c1]);
            }
        }
        return result.ToString();
    }

    private static void GetPosition(char[,] matrix, char c, out int row, out int col)
    {
        for (row = 0; row < 5; row++)
        {
            for (col = 0; col < 5; col++)
            {
                if (matrix[row, col] == c)
                    return;
            }
        }
        row = col = -1;
    }

    // ===== Cifra de Vigenère =====
    private static string VigenereEncrypt(string text, string key)
    {
        StringBuilder result = new StringBuilder();
        text = text.ToUpper();
        key = key.ToUpper();

        int keyIndex = 0;

        foreach (char c in text)
        {
            if (char.IsLetter(c))
            {
                int shift = key[keyIndex % key.Length] - 'A';
                char encryptedChar = (char)((c - 'A' + shift) % 26 + 'A');
                result.Append(encryptedChar);
                keyIndex++;
            }
            else
            {
                result.Append(c);
            }
        }
        return result.ToString();
    }

    private static string VigenereDecrypt(string text, string key)
    {
        StringBuilder result = new StringBuilder();
        text = text.ToUpper();
        key = key.ToUpper();

        int keyIndex = 0;

        foreach (char c in text)
        {
            if (char.IsLetter(c))
            {
                int shift = key[keyIndex % key.Length] - 'A';
                char decryptedChar = (char)((c - 'A' - shift + 26) % 26 + 'A');
                result.Append(decryptedChar);
                keyIndex++;
            }
            else
            {
                result.Append(c);
            }
        }
        return result.ToString();
    }
}
